-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2022 at 06:08 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(5) NOT NULL,
  `book_name` varchar(50) NOT NULL,
  `book_img` varchar(100) NOT NULL,
  `book_atuthor` varchar(50) NOT NULL,
  `publication_name` varchar(50) NOT NULL,
  `book_date` varchar(10) NOT NULL,
  `book_price` varchar(50) NOT NULL,
  `book_qty` int(5) NOT NULL,
  `abl_qty` int(5) NOT NULL,
  `lib_username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `book_name`, `book_img`, `book_atuthor`, `publication_name`, `book_date`, `book_price`, `book_qty`, `abl_qty`, `lib_username`) VALUES
(20, 'harry potter', '20220320050324.png', 'j k rawling', 'angur pokasoni', '1995-11-08', '700', 30, 29, 'kh5'),
(21, 'himu', '20220320050318.png', 'humaiun ahmed', 'seva pokasoni', '1999-02-05', '250', 40, 39, 'kh5'),
(22, 'php core project', '20220321050347.png', 'motaleb', 'motaleb publication', '2016-12-12', '52', 40, 39, 'kh5'),
(23, 'information tecnology', '20220321050354.png', 'kh rifat', 'ict publications', '2020-12-05', '250', 12, 9, 'kh5'),
(25, 'pussport', '20220321050309.png', 'nasa', 'nasa pulised', '2022-12-12', '150', 15, 14, 'kh5');

-- --------------------------------------------------------

--
-- Table structure for table `issue_book`
--

CREATE TABLE `issue_book` (
  `id` int(25) NOT NULL,
  `student_id` int(25) NOT NULL,
  `book_id` int(25) NOT NULL,
  `book_issue_date` varchar(25) NOT NULL,
  `book_return_date` varchar(25) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issue_book`
--

INSERT INTO `issue_book` (`id`, `student_id`, `book_id`, `book_issue_date`, `book_return_date`, `datetime`) VALUES
(13, 22, 20, '21-Mar-2022', '', '2022-03-21 16:55:21'),
(14, 23, 21, '21-Mar-2022', '', '2022-03-21 16:55:36'),
(15, 24, 23, '21-Mar-2022', '', '2022-03-21 16:55:45'),
(16, 24, 25, '21-Mar-2022', '21-Mar-2022', '2022-03-21 16:56:01'),
(17, 22, 22, '21-Mar-2022', '', '2022-03-21 16:56:09'),
(18, 24, 23, '21-Mar-2022', '', '2022-03-21 16:56:20'),
(19, 23, 25, '21-Mar-2022', '', '2022-03-21 16:56:27'),
(20, 22, 21, '21-Mar-2022', '21-Mar-2022', '2022-03-21 16:56:36'),
(21, 24, 20, '21-Mar-2022', '21-Mar-2022', '2022-03-21 16:56:45'),
(22, 23, 23, '21-Mar-2022', '', '2022-03-21 16:56:51'),
(23, 23, 20, '21-Mar-2022', '21-Mar-2022', '2022-03-21 16:57:00');

-- --------------------------------------------------------

--
-- Table structure for table `lib`
--

CREATE TABLE `lib` (
  `id` int(3) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(100) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lib`
--

INSERT INTO `lib` (`id`, `firstname`, `lastname`, `email`, `username`, `password`, `datetime`) VALUES
(1, 'kh', 'rifat', 'khrifat@gmail.com', 'kh5', '123', '2022-03-15 09:00:15'),
(2, 'admin', 'admin', 'admin@gamil.com', 'admin', 'admin', '2022-03-21 16:43:59');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(4) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `roll` int(12) NOT NULL,
  `reg` int(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  `stutas` tinyint(1) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `fname`, `lname`, `roll`, `reg`, `email`, `username`, `password`, `phone`, `image`, `stutas`, `datetime`) VALUES
(22, 'kh', 'rifat', 1111, 111111, 'rifat@gmail.com', 'khrifat', '123456', '01757800905', NULL, 1, '2022-03-21 16:50:18'),
(23, 'ifa', 'islam', 2222, 222222, 'ifa@yahoo.com', 'ifaislam', '123456', '01711112222', NULL, 1, '2022-03-21 16:51:58'),
(24, 'sh ', 'sifat', 3333, 333333, 'sifat@gmail.com', 'shsifat', '123456', '01733334444', NULL, 1, '2022-03-21 16:53:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issue_book`
--
ALTER TABLE `issue_book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lib`
--
ALTER TABLE `lib`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `issue_book`
--
ALTER TABLE `issue_book`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `lib`
--
ALTER TABLE `lib`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
