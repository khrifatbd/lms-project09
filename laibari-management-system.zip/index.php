<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="asset/vendor/bootstrap/css/bootstrap.css">
</head>
<body>
    <div class="container">
    <div class="row"><br><br>
        <div class="col-sm-4 col-sm-offset-4">
            <a class="btn btn-primary btn-block" href="student/log-in.php">Students</a>
            <a class="btn btn-primary btn-block" href="lib/log-in.php">Laibarian</a>
        </div>
    </div>
    </div>
</body>
</html>