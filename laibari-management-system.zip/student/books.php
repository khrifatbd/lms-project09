<?php require_once "header.php"; ?>
<div class="col-md-12">
<div class="panel">
    <div class="panel-content">
        <form class="" method="POST" action="">
            <div class="row pt-md">
                <div class="form-group col-sm-9 col-lg-10">
                        <span class="input-with-icon">
                    <input name="result" type="text" class="form-control" id="lefticon" placeholder="Search">
                    <i class="fa fa-search"></i>
                </span>
                </div>
                <div class="form-group col-sm-3  col-lg-2 ">
                    <button type="submit" name="" class="btn btn-primary btn-block">Search</button>
                </div>
            </div>
        </form>
    </div>
</div>
</div>
<?php
if(isset($_POST['search_book'])){
  $result =  $_POST['result'];
}else{    
?>
<div class="col-sm-12">
    <div class="panel">
        <div class="panel-content">
            <div class="row">
                <?php 
                    $result = mysqli_query($link, "SELECT * FROM `books`;");
                    
                    while($row = mysqli_fetch_assoc($result)){
                ?>
                <div class="col-sm-4 col-md-3">
                    <img width="200px" height="200px" src="../lib/images/book/<?= $row['book_img']; ?>" alt="">
                    <h4><?= ucwords($row['book_name']); ?></h4>
                    <span>Abailable:<?= $row['abl_qty']; ?></span>s
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<?php
}
?>

<?php require_once "footer.php"; ?>