<?php
 require_once "../dbcon.php";
 session_start();
 if(isset($_SESSION['student_login'])){
    header('location:index.php');
}
 if(isset($_POST['student-reg'])){
     $fname = $_POST['fname'];
     $lname = $_POST['lname'];
     $email = $_POST['email'];
     $username = $_POST['username'];
     $password = $_POST['password'];
     $roll = $_POST['roll'];
     $reg = $_POST['reg'];
     $phone = $_POST['phone'];

     $input_error = array();
     if(empty($fname)){
         $input_error['fname'] = "First Name is Required!";
     }
     if(empty($lname)){
         $input_error['lname'] = "Last Name is Required!";
     }
     if(empty($email)){
         $input_error['email'] = "Email is Required!";
     }
     if(empty($username)){
         $input_error['username'] = "User Name is Required!";
     }
     if(empty($password)){
         $input_error['password'] = "Password is Required!";
     }
     if(empty($roll)){
         $input_error['roll'] = "Roll is Required!";
     }
     if(empty($reg)){
         $input_error['reg'] = "Registion Number is Required!";
     }
     if(empty($phone)){
         $input_error['phone'] = "Phone Number is Required!";
     }

     if(count($input_error) == 0){
       $email_cheak = mysqli_query($link, "SELECT * FROM `student` WHERE `email` = '$email'");
        $email_cheak_row = mysqli_num_rows($email_cheak);
        if($email_cheak_row == 0){
            $username_cheak = mysqli_query($link, "SELECT * FROM `student` WHERE `username` = '$username'");
             $username_cheak_row = mysqli_num_rows($username_cheak);
            if($username_cheak_row == 0 ){
                if(strlen($username) > 5){
                    if(strlen($password) > 5){
                         $result = mysqli_query($link, "INSERT INTO `student`(`fname`, `lname`, `roll`, `reg`, `email`, `username`, `password`,`stutas`, `phone`) VALUES ('$fname','$lname','$roll','$reg','$email','$username','$password','0','$phone')");
                        if($result){
                            $success ="Registation Success!";
                            header('location:index.php');
                        }else{
                            $error = "someting worang!";
                        }
                    }else{
                        $password_ex ="password more then 6 carectar.";
                    }    
                }else{
                $username_ex ="Username more then 6 carectar.";
            }
            }else{
                $username_ex ="Username already used.";
            }
        }else{
            $email_ex = "This email already use.";
        }
     }

 }


?>
<!doctype html>
<html lang="en" class="fixed accounts sign-in">


<!-- Mirrored from myiideveloper.com/helsinki/last-version/helsinki_green-dark/src/pages_register.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Mar 2019 13:06:17 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>Student Register</title>
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
    <link rel="icon" type="image/png" sizes="192x192" href="favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
    <!--BASIC css-->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="../asset/vendor/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../asset/vendor/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="../asset/vendor/animate.css/animate.css">
    <!--SECTION css-->
    <!-- ========================================================= -->
    <!--TEMPLATE css-->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="../asset/stylesheets/css/style.css">
</head>

<body>
<div class="wrap">
    <!-- page BODY -->
    <!-- ========================================================= -->
    <div class="page-body animated slideInDown">
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
        <!--LOGO-->
        <div class="logo">
            <h2 class="text-center ">LMS</h2>
            <?php if(isset($success)){ ?>
             <div class="alert alert-success"> <?= $success; ?> </div>
            <?php } ?> 
            <?php if(isset($error)){ ?>
             <div class="alert alert-danger"> <?= $error; ?> </div>
            <?php } ?> 
            <?php if(isset($email_ex)){ ?>
             <div class="alert alert-danger"> <?= $email_ex; ?> </div>
            <?php } ?> 
            <?php if(isset($username_ex)){ ?>
             <div class="alert alert-danger"> <?= $username_ex; ?> </div>
            <?php } ?> 
            <?php if(isset($password_ex)){ ?>
             <div class="alert alert-danger"> <?= $password_ex; ?> </div>
            <?php } ?> 
        </div>
        <div class="box">
            <!--SIGN IN FORM-->
            <div class="panel mb-none">
                <div class="panel-content bg-scale-0">
                    <form method="post" action="">
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" class="form-control" name="fname" placeholder="First Name" value="<?=  isset($fname) ? $fname:'' ?>">
                                <i class="fa fa-user"></i>
                            </span>
                            <?php
                                if(isset($input_error['fname'])){
                                    echo '<span class="input-error"> '.$input_error['fname'].'</span>' ; 
                                }
                            ?>
                        </div>
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" class="form-control" name="lname" placeholder="Last Name" value="<?=  isset($lname) ? $lname:'' ?>">
                                <i class="fa fa-user"></i>
                            </span>
                            <?php
                                if(isset($input_error['lname'])){
                                    echo '<span class="input-error"> '.$input_error['lname'].'</span>' ; 
                                }
                            ?>
                        </div>
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="email" class="form-control" name="email" placeholder="Email" value="<?=  isset($email) ? $email:'' ?>">
                                <i class="fa fa-envelope"></i>
                            </span>
                            <?php
                                if(isset($input_error['email'])){
                                    echo '<span class="input-error"> '.$input_error['email'].'</span>' ; 
                                }
                            ?>
                        </div>
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" class="form-control" name="username" placeholder="User Name" value="<?=  isset($username) ? $username:'' ?>">
                                <i class="fa fa-user"></i>
                            </span>
                            <?php
                                if(isset($input_error['username'])){
                                    echo '<span class="input-error"> '.$input_error['username'].'</span>' ; 
                                }
                            ?>
                        </div>
                        <div class="form-group">
                            <span class="input-with-icon">
                                <input type="password" class="form-control" name="password" placeholder="Password" value="">
                                <i class="fa fa-key"></i>
                            </span>
                            <?php
                                if(isset($input_error['password'])){
                                    echo '<span class="input-error"> '.$input_error['password'].'</span>' ; 
                                }
                            ?>
                        </div>
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" class="form-control" name="roll" placeholder="Roll" pattern="[0-9]{4}" value="<?=  isset($roll) ? $roll:'' ?>">
                                <i class="fa fa-user"></i>
                            </span>
                            <?php
                                if(isset($input_error['roll'])){
                                    echo '<span class="input-error"> '.$input_error['roll'].'</span>' ; 
                                }
                            ?>
                        </div>
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" class="form-control" name="reg" placeholder="Registion" pattern="[0-9]{6}" value="<?=  isset($reg) ? $reg:'' ?>">
                                <i class="fa fa-user"></i>
                            </span>
                            <?php
                                if(isset($input_error['reg'])){
                                    echo '<span class="input-error"> '.$input_error['reg'].'</span>' ; 
                                }
                            ?>
                        </div>
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" class="form-control" name="phone" placeholder="017********" pattern="01[1|5|6|7|8|9][0-9]{8}" value="<?=  isset($phone) ? $phone:'' ?>" >
                                <i class="fa fa-user"></i>
                            </span>
                            <?php
                                if(isset($input_error['phone'])){
                                    echo '<span class="input-error"> '.$input_error['phone'].'</span>' ; 
                                }
                            ?>
                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-primary btn-block" name="student-reg" value="Register">
                        </div>
                        <div class="form-group text-center">
                            Have an account?, <a href="Log-in.php">Sign In</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
    </div>
</div>
<!--BASIC scripts-->
<!-- ========================================================= -->
<script src="../asset/vendor/jquery/jquery-1.12.3.min.js"></script>
<script src="../asset/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../asset/vendor/nano-scroller/nano-scroller.js"></script>
<!--TEMPLATE scripts-->
<!-- ========================================================= -->
<script src="../asset/javascripts/template-script.min.js"></script>
<script src="../asset/javascripts/template-init.min.js"></script>
<!-- SECTION script and examples-->
<!-- ========================================================= -->
</body>


<!-- Mirrored from myiideveloper.com/helsinki/last-version/helsinki_green-dark/src/pages_register.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Mar 2019 13:06:17 GMT -->
</html>
