<?php
require_once '../dbcon.php';
$id = base64_decode($_GET['id']);

mysqli_query($link, "UPDATE `student` SET `stutas`='0' WHERE `id` = '$id'");
header('location:student.php');



?>