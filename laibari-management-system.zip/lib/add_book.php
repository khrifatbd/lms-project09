<?php require_once "header.php";

if(isset($_POST['save_book'])){

    $book_name = $_POST['book_name'];
    $book_atuthor = $_POST['book_atuthor'];
    $publication_name = $_POST['publication_name'];
    $book_date = $_POST['book_date'];
    $book_price = $_POST['book_price'];
    $book_qty = $_POST['book_qty'];
    $abl_qty = $_POST['abl_qty'];
    $lib_username = $_SESSION['lib_username'];

    $image = explode('.',$_FILES['book_img']['name']);
    $image_ex = end($image);
    $image = date(format:'Ymdhms').'.'.$image_ex;
    
    if(empty($book_name)){
       $error = "plese enter book name";
    }else{
        if(empty($image)){
            $error = "plese enter book image";
         }else{
            if(empty($book_atuthor)){
                $error = "plese enter book atuthor";
             }else{
                if(empty($publication_name)){
                    $error = "plese enter book publication name";
                 }else{
                    if(empty($book_date)){
                        $error = "plese enter publised date";
                     }else{
                        if(empty($book_price)){
                            $error = "plese enter  book price";
                         }else{
                            if(empty($book_qty)){
                                $error = "plese enter  book qunatiti";
                             }else{
                                if(empty($abl_qty)){
                                    $error = "plese enter  Abilabole qunatitit";
                                 }else{
                                    $result = mysqli_query($link, "INSERT INTO `books`(`book_name`, `book_img`, `book_atuthor`, `publication_name`, `book_date`, `book_price`, `book_qty`, `abl_qty`, `lib_username`) VALUES ('$book_name','$image','$book_atuthor','$publication_name','$book_date','$book_price','$book_qty','$abl_qty','$lib_username')");
                                    if($result){
                                        move_uploaded_file($_FILES['book_img']['tmp_name'],'images/book/'.$image);
                                        $success = "Book insert successfully!";
                                    }else{
                                        $error = "something worng!";
                                    }
                                 }
                             }
                         }
                     }
                 }
             }
         }
    }

}



?>
                <!-----------------------content-------------------->


                <div class="col-sm-8 col-sm-offset-2">
                                    <form class="form-horizontal form-stripe" action="" method="post" enctype="multipart/form-data">
                                        <h6 class="mb-xlg text-center"><b>Add book in libary!</b></h6>
                                        
            <?php if(isset($error)){ ?>
             <div class="alert alert-danger col-sm-8 col-sm-offset-4"> <?= $error; ?> </div>
            <?php } ?> 
             <?php if(isset($success)){ ?>
             <div class="alert alert-success col-sm-8 col-sm-offset-4"> <?= $success; ?> </div>
            <?php } ?> 
                                        <div class="form-group">
                                            <label for="book_name" class="col-sm-4 control-label">Book Name</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="book_name" placeholder="Book Name" name="book_name">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_img" class="col-sm-4 control-label">Book Image</label>
                                            <div class="col-sm-8">
                                                <input type="file" class="form-control" id="book_img" placeholder="book img" name="book_img">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_atuthor" class="col-sm-4 control-label">Book Author</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="book_atuthor" placeholder="Book Author" name="book_atuthor">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="publication_name" class="col-sm-4 control-label">Publication Name</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="publication_name" placeholder="Publication Name" name="publication_name">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_date" class="col-sm-4 control-label">Publised Date</label>
                                            <div class="col-sm-8">
                                                <input type="date" class="form-control" id="book_date" placeholder="Publised Date" name="book_date">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_price" class="col-sm-4 control-label">Book Price</label>
                                            <div class="col-sm-8">
                                                <input type="number" class="form-control" id="book_price" placeholder="Book Price" name="book_price">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_qty" class="col-sm-4 control-label">Book Qountity</label>
                                            <div class="col-sm-8">
                                                <input type="number" class="form-control" id="book_qty" placeholder="Book Qountity" name="book_qty">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="abl_qty" class="col-sm-4 control-label">Abillive Qountity</label>
                                            <div class="col-sm-8">
                                                <input type="number" class="form-control" id="abl_qty" placeholder="Abillive Qountity" name="abl_qty">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-offset-4 col-sm-8">
                                                <button type="submit" class="btn btn-primary" name="save_book">Save Book</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                
 <?php require_once "footer.php"; ?>