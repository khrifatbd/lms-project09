<?php require_once "header.php"; ?>
                <!-----------------------content-------------------->


            <!--SEARCHING, ORDENING & PAGING-->
<div class="row animated fadeInRight">
    <div class="col-sm-12">
        <h4 class="section-subtitle"><b>All Students</b></h4>
        <div class="pull-right"><a href="print_student.php" class="btn btn-info" target="_blank"><i class="fa fa-print"> </i> Print</a></div>
        <div class="panel">
            <div class="panel-content">
                <div class="table-responsive">
                    <table id="basic-table" class="data-table table table-striped nowrap table-hover" cellspacing="0" width="100%">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Roll No.</th>
                            <th>Reg No.</th>
                            <th>Email</th>
                            <th>User Name</th>
                            <th>Phone</th>
                            <th>Stutas</th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
<?php
    $result = mysqli_query($link, "SELECT * FROM `student`");
    while($row = mysqli_fetch_assoc($result)){
?>
                        <tr>
                            <td><?= ucwords($row['fname']).' '.$row['lname'];  ?></td>
                            <td><?= ucwords($row['roll']); ?></td>
                            <td><?= ucwords($row['reg']); ?></td>
                            <td><?= $row['email']; ?></td>
                            <td><?= $row['username']; ?></td>
                            <td><?= ucwords($row['phone']); ?></td>
                            <td><?= $row['stutas'] == 1 ? 'Active':'Inactive'; ?></td>
                            <td><img src="<?= $row['image']; ?>" alt=""></td>
                            <td>
                                <?php
                                     if($row['stutas'] == 1){
                                 ?>            
                                  <a href="stutas_inactive.php?id=<?= base64_encode($row['id']); ?>" class="btn btn-primary"><i class="fa fa-arrow-up"></i> </a>
                                <?php        
                                     }else{
                                ?>  
                                    <a href="stutas_active.php?id=<?= base64_encode($row['id']); ?>" class="btn btn-danger"><i class="fa fa-arrow-down"></i> </a>
                                <?php 
                                     }
                                ?>
                            </td>
                        </tr>
<?php
    }
?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

                
 <?php require_once "footer.php"; ?>