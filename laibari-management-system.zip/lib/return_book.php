<?php require_once "header.php"; ?>
                <!-----------------------content-------------------->


            <!--SEARCHING, ORDENING & PAGING-->
<div class="row animated fadeInRight">
    <div class="col-sm-12">
        <h4 class="section-subtitle"><b>Return Books</b></h4>
        <div class="panel">
            <div class="panel-content">
                <div class="table-responsive">
                    <table id="basic-table" class="data-table table table-striped nowrap table-hover table-bordered" cellspacing="0" width="100%">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Roll No.</th>
                            <th>Phone</th>
                            <th>Book Name</th>
                            <th>Book image</th>
                            <th>Issue Date</th>
                            <th>Return Date</th>
                        </tr>
                        </thead>
                        <tbody>
<?php
    $result = mysqli_query($link, "SELECT issue_book.book_id, issue_book.book_issue_date,issue_book.id, student.fname, student.lname, student.roll, student.phone, books.book_name, books.book_img
    from issue_book
    INNER JOIN student on student.id = issue_book.student_id
    INNER JOIN books ON books.id = issue_book.book_id
    WHERE issue_book.book_return_date = ''");
    while($row = mysqli_fetch_assoc($result)){
?>
                        <tr>
                            <td><?= ucwords($row['fname']).' '.$row['lname'];  ?></td>
                            <td><?= $row['roll']; ?></td>
                            <td><?= ucwords($row['phone']); ?></td>
                            <td><?= ucwords($row['book_name']); ?></td>
                            <td><img width="100px" src="images/book/<?= $row['book_img']; ?>" alt="data"></td>
                            <td><?= ucwords($row['book_issue_date']); ?></td>
                            <td><a href="return_book.php?id=<?= $row['id']; ?>&bookid=<?= $row['book_id']; ?>" class="btn btn-info">Return Book</a></td>
                        </tr>
<?php
    }
?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
if(isset($_GET['id'])){
    $id= $_GET['id'];
    $book_id= $_GET['bookid'];
    $date = date('d-M-Y');
    $result = mysqli_query($link, "UPDATE `issue_book` SET `book_return_date`='$date' WHERE `id` = '$id'");
    if($result){
        mysqli_query($link, "UPDATE `books` SET `abl_qty`=`abl_qty`+1 WHERE `id` ='$book_id'");
?>
<script>
    alert('book return successfully.');
</script>
<?php
    }else{
        ?>
        <script>
            alert('something worng.');
        </script>
        <?php
    }
}
?>
                
 <?php require_once "footer.php"; ?>