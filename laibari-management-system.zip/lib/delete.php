<?php
require_once "../dbcon.php";

if(isset($_GET['bookdelete'])){
  $id = base64_decode($_GET['bookdelete']);
  mysqli_query($link, "DELETE FROM `books` WHERE `id` = '$id'");
  header('location:manage_book.php');
}

?>