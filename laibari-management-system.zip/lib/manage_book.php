<?php require_once "header.php"; ?>
                <!-----------------------content-------------------->

            <!--SEARCHING, ORDENING & PAGING-->
            <div class="row animated fadeInRight">
    <div class="col-sm-12">
        <h4 class="section-subtitle"><b>All Books</b></h4>
        <div class="panel">
            <div class="panel-content">
                <div class="table-responsive">
                    <table id="basic-table" class="data-table table table-striped nowrap table-hover" cellspacing="0" width="100%">
                        <thead>
                        <tr>
                            <th>Book Names</th>
                            <th>Book Image</th>
                            <th>Publication Name</th>
                            <th>Author Name</th>
                            <th>Percase Date</th>
                            <th>Book Price</th>
                            <th>Book Quntity</th>
                            <th>Avilable Quntity</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
<?php
    $result = mysqli_query($link, "SELECT * FROM `books`");
    while($row = mysqli_fetch_assoc($result)){
?>
                        <tr>
                            <td><?= ucwords($row['book_name']); ?></td>
                            <td><img width="80px" src="images/book/<?= $row['book_img']; ?>" alt="Books Img"></td>
                            <td><?= ucwords($row['publication_name']); ?></td>
                            <td><?= ucwords($row['book_atuthor']); ?></td>
                            <td><?= date('d-M-Y',strtotime($row['book_date'])); ?></td>
                            <td><?= $row['book_price']; ?></td>
                            <td><?= $row['book_qty']; ?></td>
                            <td><?= $row['abl_qty']; ?></td>
                            <td>
                                
                              <a href="" class="btn btn-info" data-toggle="modal" data-target="#book-<?= $row['id']; ?>"><i class="fa fa-eye"></i> </a>  
                              <a href="" class="btn btn-warning"  data-toggle="modal" data-target="#book-update-<?= $row['id']; ?>"><i class="fa fa-pencil"></i> </a>  
                              <a href="delete.php?bookdelete=<?= base64_encode($row['id']); ?>" class="btn btn-danger" onclick ="return confirm('are you sure to delete this book?')"><i class="fa fa-trash"></i> </a>  
                            </td>
                        </tr>
<?php
    }
?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!------------- edit--------------- -->
<?php

    $result = mysqli_query($link, "SELECT * FROM `books`");
    while($row = mysqli_fetch_assoc($result)){
        $id = $row['id'];
        $book_info = mysqli_query($link, "SELECT * FROM `books` where `id` = '$id'");
        $book_in_row = mysqli_fetch_assoc($book_info);
?>
<!-- Modal -->
<div class="modal fade" id="book-update-<?= $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="modal-info-label">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header state modal-info">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="modal-info-label"><i class="fa fa-book"></i>Update Book info</h4>
            </div>
            <div class="modal-body">
                    <div class="panel">
                        <div class="panel-content">
                            <div class="row">
                                <div class="col-sm-12">
                                    <form class="form-horizontal form-stripe" method="POST" action="">
                                        <div class="form-group">
                                            <label for="book_name" class="col-sm-4 control-label">Book Name</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="book_name" placeholder="Book Name" name="book_name" value="<?= $book_in_row['book_name']; ?>">
                                                <input type="hidden" class="form-control" id="id"  name="id" value="<?= $book_in_row['id']; ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_atuthor" class="col-sm-4 control-label">Book Author</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="book_atuthor" placeholder="Book Author" name="book_atuthor" value="<?= $book_in_row['book_atuthor']; ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="publication_name" class="col-sm-4 control-label">Publication Name</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="publication_name" placeholder="Publication Name" name="publication_name" value="<?= $book_in_row['publication_name']; ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_date" class="col-sm-4 control-label">Publised Date</label>
                                            <div class="col-sm-8">
                                                <input type="date" class="form-control" id="book_date" placeholder="Publised Date" name="book_date" value="<?= $book_in_row['book_date']; ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_price" class="col-sm-4 control-label">Book Price</label>
                                            <div class="col-sm-8">
                                                <input type="number" class="form-control" id="book_price" placeholder="Book Price" name="book_price" value="<?= $book_in_row['book_price']; ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_qty" class="col-sm-4 control-label">Book Qountity</label>
                                            <div class="col-sm-8">
                                                <input type="number" class="form-control" id="book_qty" placeholder="Book Qountity" name="book_qty" value="<?= $book_in_row['book_qty']; ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="abl_qty" class="col-sm-4 control-label">Abillive Qountity</label>
                                            <div class="col-sm-8">
                                                <input type="number" class="form-control" id="abl_qty" placeholder="Abillive Qountity" name="abl_qty" value="<?= $book_in_row['abl_qty']; ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-offset-4 col-sm-8">
                                                <button type="submit" class="btn btn-primary" name="update_book">Update Book</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
 <?php
    }
    if(isset($_POST['update_book'])){

        $id = $_POST['id'];
        $book_name = $_POST['book_name'];
        $book_atuthor = $_POST['book_atuthor'];
        $publication_name = $_POST['publication_name'];
        $book_date = $_POST['book_date'];
        $book_price = $_POST['book_price'];
        $book_qty = $_POST['book_qty'];
        $abl_qty = $_POST['abl_qty'];
        $lib_username = $_SESSION['lib_username'];
        
        if(empty($book_name)){
           $error = "plese enter book name";
        }else{
                if(empty($book_atuthor)){
                    $error = "plese enter book atuthor";
                 }else{
                    if(empty($publication_name)){
                        $error = "plese enter book publication name";
                     }else{
                        if(empty($book_date)){
                            $error = "plese enter publised date";
                         }else{
                            if(empty($book_price)){
                                $error = "plese enter  book price";
                             }else{
                                if(empty($book_qty)){
                                    $error = "plese enter  book qunatiti";
                                 }else{
                                    if(empty($abl_qty)){
                                        $error = "plese enter  Abilabole qunatitit";
                                     }else{
                                        $result = mysqli_query($link, "UPDATE `books` SET `book_name`='$book_name',`book_atuthor`='$book_atuthor',`publication_name`='$publication_name',`book_date`='$book_date',`book_price`='$book_price',`book_qty`='$book_qty',`abl_qty`='$abl_qty',`lib_username`='$lib_username' WHERE `id` = '$id'");
                                        if($result){
                                        }
                                     }
                                 }
                             }
                         }
                     }
                 
             }
        }
    
    }
    
?>                            
     

<!-----  veiw ----------------------- -->
<?php
    $result = mysqli_query($link, "SELECT * FROM `books`");
    while($row = mysqli_fetch_assoc($result)){
?>
<!-- Modal -->
<div class="modal fade" id="book-<?= $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="modal-info-label">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header state modal-info">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="modal-info-label"><i class="fa fa-book"></i>Book Information</h4>
            </div>
            <div class="modal-body">
                <table class="table table-striped">  
                    <tr>
                        <th>Book Names</th>
                        <td><?= ucwords($row['book_name']); ?></td>
                    </tr>
                    <tr>
                        <th>Book Image</th>
                        <td><img width="200px" src="images/book/<?= $row['book_img']; ?>" alt="Books Img"></td>
                    </tr>
                    <tr>
                        <th>Publication Name</th>
                        <td><?= ucwords($row['publication_name']); ?></td>
                    </tr>
                    <tr>
                        <th>Author Name</th>
                        <td><?= ucwords($row['book_atuthor']); ?></td>
                    </tr>
                    <tr>
                        <th>Percase Date</th>
                        <td><?= date('d-M-Y',strtotime($row['book_date'])); ?></td>
                    </tr>
                    <tr>
                        <th>Book Price</th>
                        <td><?= $row['book_price']; ?></td>
                    </tr>
                    <tr>
                        <th>Book Quntity</th>
                        <td><?= $row['book_qty']; ?></td>
                    </tr>
                    <tr>
                        <th>Avilable Quntity</th>
                        <td><?= $row['abl_qty']; ?></td>
                    </tr>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
 <?php
    }
?>                            
                
 <?php require_once "footer.php"; ?>

 