<?php require_once "header.php"; ?>
                <!-----------------------content-------------------->
                <div class="row">
                    <!--BOX Style 1-->
                    <?php
$student = mysqli_query($link, "SELECT * FROM `student` ");
$total_student = mysqli_num_rows($student);
//$data = mysqli_fetch_assoc($data);
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="panel widgetbox wbox-1 bg-lighter-2 color-light">
                            <a href="student.php">
                                <div class="panel-content">
                                    <h1 class="title color-darker-2"> <i class="fa fa-users"></i> <?=
 $total_student;?> </h1>
                                    <h4 class="subtitle color-darker-1">Total Students.</h4>
                                </div>
                            </a>
                        </div>
                    </div>    
                    <!--BOX Style 2-->
                    <?php
$lib = mysqli_query($link, "SELECT * FROM `lib` ");
$total_lib = mysqli_num_rows($lib);
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="panel widgetbox wbox-1 bg-lighter-2 color-light">
                            <a href="">
                                <div class="panel-content">
                                    <h1 class="title color-darker-2"> <i class="fa fa-users"></i> <?=
 $total_lib;?> </h1>
                                    <h4 class="subtitle color-darker-1">Total Laibarian.</h4>
                                </div>
                            </a>
                        </div>
                    </div> 

                <div class="row col-sm-12">
                    <!--BOX Style 3-->
                    <?php
$book = mysqli_query($link, "SELECT * FROM `books` ");
$total_book = mysqli_num_rows($book);
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="panel widgetbox wbox-1 bg-lighter-2 color-light">
                            <a href="manage_book.php">
                                <div class="panel-content">
                                    <h1 class="title color-darker-2"> <i class="fa fa-book"></i> <?=
 $total_book;?> </h1>
                                    <h4 class="subtitle color-darker-1">Total Book.</h4>
                                </div>
                            </a>
                        </div>
                    </div> 
                    <!--BOX Style 3-->
                    <?php
$book_q = mysqli_query($link, "SELECT SUM(`book_qty`) AS total FROM `books`;");
$book_qty = mysqli_fetch_assoc($book_q);
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="panel widgetbox wbox-1 bg-lighter-2 color-light">
                            <a href="return_book.php">
                                <div class="panel-content">
                                    <h1 class="title color-darker-2"> <i class="fa fa-book"></i> <?= $book_qty['total'];?>
  </h1>
                                    <h4 class="subtitle color-darker-1">Total Book Quntitay.</h4>
                                </div>
                            </a>
                        </div>
                    </div>  
                </div>     
 <?php require_once "footer.php"; ?>