<?php require_once "header.php"; ?>
<?php
if(isset($_POST['issue_book'])){
    $student_id = $_POST['student_id'];
    $book_id = $_POST['book-id'];
    $book_issue_date = $_POST['book-issue-date'];
    $result = mysqli_query($link, "INSERT INTO `issue_book`(`student_id`, `book_id`, `book_issue_date`) VALUES ('$student_id', '$book_id', '$book_issue_date')"); 
   
    if($result){
        mysqli_query($link, "UPDATE `books` SET `abl_qty`=`abl_qty`-1 WHERE `id` ='$book_id'");
?>
    <script type="text/javascript">
        alert('Book issue successfully');
    </script>
<?php        
    }else{
?>
        <script type="text/javascript">
            alert('some problem.');
        </script>
<?php 
    }
}

?>
<!-----------------------content-------------------->
<div class="panel col-md-8 col-md-offset-2">
                        <div class="panel-content">
                            <div class="row">
                                <div class="col-md-6">
                                    <form class="form-inline" action="" method="POST">
                                        <div class="form-group">
                                            <select name="student-id" id="" class="form-control">
                                                <option value="">select</option>
<?php
    $result = mysqli_query($link, "SELECT * FROM `student` where `stutas` = '1'");
    while($row = mysqli_fetch_assoc($result)){
?>
                                                <option value="<?= $row['id']; ?>"><?= ucwords($row['fname']).' '.$row['lname'].'--'.$row['roll'].' '; ?></option>
<?php } ?>
                                            </select>
                                        </div>
                                            <button type="submit" class="btn btn-primary" name="search">Search</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
 <?php
    if(isset($_POST['search'])){
        $id = $_POST['student-id'];
        
        $result = mysqli_query($link, "SELECT * FROM `student` WHERE `id` = '$id' AND `stutas` = '1'");
        $row  = mysqli_fetch_assoc($result);
?>
                                <form method="POST">
                                    <div class="form-group">
                                        <label for="name">Student Name</label>
                                        <input type="text" class="form-control" id="name" value="<?= ucwords($row['fname']).' '.$row['lname']; ?>" readonly>
                                        <input type="hidden" value="<?= $row['id'] ?>" name="student_id">
                                    </div>
                                    <div class="form-group">
                                        <label for="book_name">Books Name</label>
                                            <select name="book-id" id="book_name" class="form-control">
                                                <option value="">select</option>
<?php
    $result = mysqli_query($link, "SELECT * FROM `books` WHERE `abl_qty` > 0");
    while($row = mysqli_fetch_assoc($result)){
?>
                                                <option value="<?= $row['id']; ?>"><?= ucwords($row['book_name']); ?></option>
<?php } ?>
                                            </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="issue-date">Book issue date</label>
                                        <input type="text" class="form-control" id="issue-date" value="<?= date('d-M-Y'); ?>" readonly name="book-issue-date">
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary" name="issue_book">Save Issue book</button>
                                    </div>
                                </form>
                        </div>
                    </div>
<?php        
        
    }
?>
                               

                
 <?php require_once "footer.php"; ?>